from django.shortcuts import render
# Create your views here.
from django.http import JsonResponse
def employee_data_jsondirectview(request):
 employee_data={'eno':100,'ename':'Naresh','esal':1000,'eaddr':'Hyderabad'}
 return JsonResponse(employee_data)
