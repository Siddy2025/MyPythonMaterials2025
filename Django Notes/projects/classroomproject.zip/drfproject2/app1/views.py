from telnetlib import STATUS
from django.shortcuts import render
from django.utils.decorators import method_decorator 
from app1.forms import EmployeeForm
# Create your views here.
from django.views.generic import View
from django.core.serializers import serialize 
from  app1.models import Employee 
import json 
from django.http import HttpResponse
from app1.minxin import *
from app1.utils import * 
from django.views.decorators.csrf import csrf_exempt
  # Create your views here. 
class EmployeeCRUDCBV(View): 
  def get(self,request,id,*args,**kwargs): 
   emp=Employee.objects.get(id=id) 
   data={ 
  'eno':emp.eno, 
  'ename':emp.ename, 
  'esal':emp.esal, 
  'eaddr':emp.eaddr, 
   } 
   json_data=json.dumps(data) 
   return HttpResponse(json_data,content_type='application/json')

class EmployeeListCBV(View): 
  def get(self,request,*args,**kwargs): 
   qs=Employee.objects.all() 
   json_data=serialize('json',qs) 
   return HttpResponse(json_data,content_type='application/json')

class EmployeeListCBV(SerializeMixin,View): 
  def get(self,request,*args,**kwargs): 
    qs=Employee.objects.all() 
    json_data=self.serialize(qs) 
    return HttpResponse    (json_data,content_type='application/json')

'''class EmployeeCRUDCBV(SerializeMixin,View): 
  def get(self,request,id,*args,**kwargs): 
    try: 
     emp=Employee.objects.get(id=id) 
    except Employee.DoesNotExist:   
  	  json_data=json.dumps({'msg':'Specified Record Not Found'})
    else: 
      json_data=self.serialize([emp,]) 
   
      
    return HttpResponse(json_data,content_type='application/json')
'''
class EmployeeCRUDCBV(SerializeMixin,HttpResponseMixin,View): 
  def get(self,request,id,*args,**kwargs): 
   try: 
    emp=Employee.objects.get(id=id) 
   except Employee.DoesNotExist: 
    json_data=json.dumps({'msg':'Specified Record Not Available'}) 
    return self.render_to_http_response(json_data,404) 
   else: 
    json_data=self.serialize([emp,]) 
   return self.render_to_http_response(json_data)

@csrf_exempt
def empInsert(request):
   if request.method=='POST':
    data=request.body
    empdict=json.loads(data)
    e=Employee()
    e.eno=empdict['eno']
    e.ename=empdict['ename']
    e.eaddr=empdict['eaddr']
    e.esal=empdict['esal']
    e.save()
    return HttpResponse(json.dumps({'msg':'resource created successfully'}),content_type='application/json',status=200)
   else:
    return HttpResponse(json.dumps({'msg':'error in creating'}),content_type='application/json',STATUS=400)

@method_decorator(csrf_exempt,name='dispatch') 
class EmployeeCRUDCBV1(SerializeMixin,HttpResponseMixin,View): 
  def get_object_by_id(self,id): 
   try: 
     emp=Employee.objects.get(id=id) 
   except Employee.DoesNotExist:
     emp=None 
   return emp 
  def put(self,request,id,*args,**kwargs): 
   obj=self.get_object_by_id(id) 
   if obj is None: 
    json_data=json.dumps({'msg':'No matched record found, Not possible to perform updataion'}) 
    return self.render_to_http_response(json_data,status=404) 
   data=request.body 
   if not is_json(data): 
    return self.render_to_http_response(json.dumps({'msg':'plz send valid jsondata only'}),status=400) 
   new_data=json.loads(data) 
   old_data={ 
   'eno':obj.eno, 
   'ename':obj.ename, 
   'esal':obj.esal, 
   'eaddr':obj.eaddr, 
   } 
   old_data['eaddr']=new_data['eaddr']
   form=EmployeeForm(old_data,instance=obj) 
   if form.is_valid(): 
     form.save(commit=True) 
     json_data=json.dumps({'msg':'Updated successfully'}) 
     return self.render_to_http_response(json_data,status=201) 
   if form.errors: 
      json_data=json.dumps(form.errors) 
      return self.render_to_http_response(json_data,status=400)
  def delete(self,request,id,*args,**kwargs): 
   obj=self.get_object_by_id(id) 
   if obj is None: 
    json_data=json.dumps({'msg':'No matched record found, Not possible to perform deletion'}) 
    return self.render_to_http_response(json_data,status=404) 
   status,deleted_item=obj.delete() 
   if status==1: 
    json_data=json.dumps({'msg':'Resource Deleted successfully'}) 
    return self.render_to_http_response(json_data,status=201)
   else:
    json_data=json.dumps({'msg':'unable to delete ...plz try again'}) 
    return self.render_to_http_response(json_data,status=500)



