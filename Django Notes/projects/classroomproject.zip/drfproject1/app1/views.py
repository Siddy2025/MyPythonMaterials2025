from django.shortcuts import render
from django.views.generic import View 
from app1 import mixins

from django.http import JsonResponse
def employee_data_jsondirectview(request):
 employee_data={'eno':100,'ename':'Naresh','esal':1000,'eaddr':'Hyderabad'}
 return JsonResponse(employee_data)

class JsonCBV(View): 
  def get(self,request,*args,**kwargs): 
    employee_data={'eno':100,'ename':'Naresh','esal':1000,'eaddr':'Hyderabad'}
    return JsonResponse(employee_data)  

class JsonCBV2(mixins.JsonResponseMixin,View): 
  def get(self,request,*args,**kwargs): 
   employee_data={'eno':100,'ename':'Naresh','esal':1000,'eaddr':'Hyderabad'}
   return self.render_to_json_response(employee_data)