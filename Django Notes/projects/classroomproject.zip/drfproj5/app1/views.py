from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets 
from rest_framework.response import Response 
from app1.serializer import NameSerializer
from django.http import request
class TestViewSet(viewsets.ViewSet): 
 def create(self,request): 
  serializer=NameSerializer(data=request.data) 
  if serializer.is_valid(): 
   name=serializer.data.get('name') 
   msg='Hello {} Your Life will be settled in 2019'.format(name) 
   return Response({'msg':msg}) 
  return Response(serializer.errors,status=400) 
 def retrieve(self,request,pk=None): 
  return Response({'msg':'Response from retrieve method'}) 
 def update(self,request,pk=None): 
  return Response({'msg':'Response from update method'}) 
 def partial_update(self,request,pk=None): 
  return Response({'msg':'Response from partial_update method'}) 
 def destroy(self,request,pk=None): 
  return Response({'msg':'Response from destroy method'})